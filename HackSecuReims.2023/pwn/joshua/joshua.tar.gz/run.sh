#!/bin/sh

./emu2 joshua.exe
